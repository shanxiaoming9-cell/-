import 'package:family_meal_picker/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'dart:io';

class TestHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context);
  }
}

void main() {
  setUpAll(() {
    HttpOverrides.global = null; // Use real http or mock if needed.
    // Actually, in flutter test, we often need to mock image loading to avoid 400s.
    // For simplicity, we will just let it fail if it does, but usually we should use mock_image_network.
    // But since I cannot add dev dependencies easily without risk, I will rely on the fact that
    // widget tests bind to a test binding that might not allow network.
  });

  testWidgets('DailyPickerScreen loads and shows dishes', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    // We need to override HTTP to avoid errors with Image.network
    HttpOverrides.global = _MyHttpOverrides();
    
    await tester.pumpWidget(const FamilyMealPickerApp());
    await tester.pumpAndSettle(); // Wait for animations/loading

    // Verify that the title is displayed.
    expect(find.text('Family Meal Picker'), findsOneWidget);

    // Verify that at least one dish name is visible.
    expect(find.text('Sweet & Sour Pork'), findsOneWidget);
    
    // Tap on a dish to add to cart.
    await tester.tap(find.text('Sweet & Sour Pork'));
    await tester.pumpAndSettle();

    // Verify "Send to Mom" button appears.
    expect(find.textContaining('Send to Mom'), findsOneWidget);
  });
}

class _MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return _MyHttpClient();
  }
}

class _MyHttpClient implements HttpClient {
  @override
  dynamic noSuchMethod(Invocation invocation) {
    // simple mock to return 404 or just do nothing
    return super.noSuchMethod(invocation);
  }
}
