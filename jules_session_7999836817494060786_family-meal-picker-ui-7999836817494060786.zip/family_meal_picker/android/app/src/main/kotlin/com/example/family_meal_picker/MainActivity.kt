package com.example.family_meal_picker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
