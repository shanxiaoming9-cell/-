import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:provider/provider.dart';
import '../models/dish.dart';
import '../providers/cart_provider.dart';
import '../widgets/dish_card.dart';
import '../widgets/category_filter.dart';

class DailyPickerScreen extends StatefulWidget {
  const DailyPickerScreen({super.key});

  @override
  State<DailyPickerScreen> createState() => _DailyPickerScreenState();
}

class _DailyPickerScreenState extends State<DailyPickerScreen> {
  String _selectedCategory = 'All';
  
  // Mock Data
  final List<Dish> _allDishes = [
    Dish(id: '1', name: 'Sweet & Sour Pork', imageUrl: 'https://images.unsplash.com/photo-1532592333383-8a2dd6c53d39', tags: ['Meat', 'Sweet'], isSpecialty: true),
    Dish(id: '2', name: 'Tomato Egg Stir-fry', imageUrl: 'https://images.unsplash.com/photo-1543826173-70651703c5a4', tags: ['Veggie', 'Quick']),
    Dish(id: '3', name: 'Steamed Fish', imageUrl: 'https://images.unsplash.com/photo-1580476262798-bddd9f4b7369', tags: ['Seafood', 'Healthy'], isSpecialty: true),
    Dish(id: '4', name: 'Braised Beef', imageUrl: 'https://images.unsplash.com/photo-1563379926898-05f457542c31', tags: ['Meat', 'Slow Cook']),
    Dish(id: '5', name: 'Mapo Tofu', imageUrl: 'https://images.unsplash.com/photo-1582294247249-14a51d382217', tags: ['Veggie', 'Spicy']),
    Dish(id: '6', name: 'Chicken Soup', imageUrl: 'https://images.unsplash.com/photo-1547592180-85f173990554', tags: ['Soup', 'Healthy']),
    Dish(id: '7', name: 'Fried Rice', imageUrl: 'https://images.unsplash.com/photo-1603133872878-684f5c9322ed', tags: ['Main', 'Quick']),
    Dish(id: '8', name: 'Dumplings', imageUrl: 'https://images.unsplash.com/photo-1496116218417-1a781b1c416c', tags: ['Main', 'Weekend']),
  ];

  final List<String> _categories = ['All', 'Meat', 'Veggie', 'Soup', 'Main', 'Healthy', 'Sweet', 'Spicy'];

  List<Dish> get _filteredDishes {
    if (_selectedCategory == 'All') return _allDishes;
    return _allDishes.where((dish) => dish.tags.contains(_selectedCategory)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            pinned: true,
            snap: false,
            centerTitle: false,
            title: const Text('Family Meal Picker'),
            backgroundColor: Theme.of(context).primaryColor,
            foregroundColor: Colors.white,
            actions: [
               IconButton(
                 icon: const Icon(Icons.history),
                 onPressed: () {},
               ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: CategoryFilter(
                categories: _categories,
                selectedCategory: _selectedCategory,
                onCategorySelected: (category) {
                  setState(() {
                    _selectedCategory = category;
                  });
                },
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16.0),
            sliver: SliverMasonryGrid.count(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childCount: _filteredDishes.length,
              itemBuilder: (context, index) {
                return DishCard(dish: _filteredDishes[index]);
              },
            ),
          ),
          // Add some bottom padding for the FAB
          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ],
      ),
      floatingActionButton: Consumer<CartProvider>(
        builder: (context, cart, child) {
          if (cart.selectedDishes.isEmpty) return const SizedBox.shrink();
          return FloatingActionButton.extended(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Sent ${cart.selectedDishes.length} dishes to Mom!')),
              );
              cart.clearCart();
            },
            icon: const Icon(Icons.send),
            label: Text('Send to Mom (${cart.selectedDishes.length})'),
            backgroundColor: Theme.of(context).primaryColor,
          );
        },
      ),
    );
  }
}
