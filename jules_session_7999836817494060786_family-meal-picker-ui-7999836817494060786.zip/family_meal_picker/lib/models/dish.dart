class Dish {
  final String id;
  final String name;
  final String imageUrl;
  final String recipe;
  final List<String> tags;
  final bool isSpecialty; // Mom's specialty

  Dish({
    required this.id,
    required this.name,
    required this.imageUrl,
    this.recipe = '',
    this.tags = const [],
    this.isSpecialty = false,
  });
}
