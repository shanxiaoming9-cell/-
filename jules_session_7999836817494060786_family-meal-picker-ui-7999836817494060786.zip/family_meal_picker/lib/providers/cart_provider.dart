import 'package:flutter/foundation.dart';
import '../models/dish.dart';

class CartProvider extends ChangeNotifier {
  final List<Dish> _selectedDishes = [];

  List<Dish> get selectedDishes => List.unmodifiable(_selectedDishes);

  void toggleDish(Dish dish) {
    if (_selectedDishes.contains(dish)) {
      _selectedDishes.remove(dish);
    } else {
      _selectedDishes.add(dish);
    }
    notifyListeners();
  }

  bool isSelected(Dish dish) {
    return _selectedDishes.contains(dish);
  }

  void clearCart() {
    _selectedDishes.clear();
    notifyListeners();
  }
}
