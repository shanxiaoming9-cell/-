import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/cart_provider.dart';
import 'screens/daily_picker_screen.dart';

void main() {
  runApp(const FamilyMealPickerApp());
}

class FamilyMealPickerApp extends StatelessWidget {
  const FamilyMealPickerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => CartProvider(),
      child: MaterialApp(
        title: 'Family Meal Picker',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.orange,
            primary: Colors.orange,
            secondary: Colors.amber,
          ),
          useMaterial3: true,
          scaffoldBackgroundColor: Colors.grey[50],
          appBarTheme: const AppBarTheme(
            elevation: 0,
            centerTitle: false,
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
          ),
        ),
        home: const DailyPickerScreen(),
      ),
    );
  }
}
