import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/dish.dart';
import '../providers/cart_provider.dart';

class DishCard extends StatelessWidget {
  final Dish dish;

  const DishCard({super.key, required this.dish});

  @override
  Widget build(BuildContext context) {
    // Consumer to rebuild only this widget when cart changes
    return Consumer<CartProvider>(
      builder: (context, cart, child) {
        final isSelected = cart.isSelected(dish);
        
        return GestureDetector(
          onTap: () {
            cart.toggleDish(dish);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: isSelected 
                  ? Border.all(color: Theme.of(context).primaryColor, width: 3) 
                  : Border.all(color: Colors.transparent, width: 3),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(13), // 16 - 3 border width
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Image
                  Stack(
                    children: [
                      AspectRatio(
                        aspectRatio: 1.0, // Square or flexible
                        child: Image.network(
                          dish.imageUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, _, __) => Container(
                            color: Colors.grey[200],
                            child: const Icon(Icons.restaurant, size: 50, color: Colors.grey),
                          ),
                        ),
                      ),
                      if (dish.isSpecialty)
                        Positioned(
                          top: 8,
                          left: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              "Mom's Best",
                              style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      if (isSelected)
                         Positioned(
                          top: 8,
                          right: 8,
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Colors.green,
                              shape: BoxShape.circle,
                            ),
                            padding: const EdgeInsets.all(4),
                            child: const Icon(Icons.check, color: Colors.white, size: 16),
                          ),
                        ),
                    ],
                  ),
                  // Name
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text(
                      dish.name,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
